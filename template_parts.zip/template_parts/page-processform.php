<?php
/**
 * Template Name: Application Process Form
 * 
 * Process of ApplicationEmail
 * 
 * ApplicationEmail Class takes $_POST as an argument and creates following objects as it's variable. 
 * 
 * 		- ApplicationForm( $input ) , $input as $_POST
 *   	- ApplicationStaff( $role, $department, $language )
 * 
 * ApplicationForm Class will take $_POST as an argument and populates 4 Category Objects ( Container Class ). 
 * 
 * 4 Category Objects includes: 
 * 
 *  	$program = new Category();
 *      $student = new Student(); ( 'Student' Class is a child class of 'Category' Class )
 *      $agent   = new Category();
 *      $other   = new Category();
 * 
 * Since the most of the keys in $_POST will have a prefix ( ex. 'student_', 'agent_', 'program_' )
 * ApplicationForm Class will strip those prefixes and insert them to appropriate Category Objects.
 *
 * 		'program_startdate' ---> $program   
 * 	 	'student_name'      ---> $student 
 * 
 * 	Every data that was inserted into a Category object can be retrieved by a single key // $student->get( 'name' )
 * 
 * 	or
 * 
 * 	an array or keys // $student->get( array( 'name', 'dob', 'language' ) ) ---> returns array of values 
 * 
 * 	Category Class also has a function called append/appendAll 
 *  which takes a reference of a string and values of following strings : 'key prefix', 'key suffix', 'value prefix', 'value suffix'
 *  
 *  So following implementation is possible 
 * 
 * 		$body = '';
 * 
 * 		$student->appendAll( $body, '<b>', ': </b>', ' <i>', '</i><br>' ); 
 * 
 * 		echo $body; 
 * 
 * 		----OUTPUT----
 * 
 * 			<b>name : </b> <i>John Cage</i><br>
 * 	  		<b>age : </b> <i>22</i><br>
 * 	    	<b>gender : </b> <i>male</i><br>
 * 
 * 		---------------
 * 
 * 	ApplicationEmail Class contains numerous Contstants , some worth to mention are 
 * 
 *  	ApplicationEmail:: QUOTE_FIELDS
 *   	ApplicationEmail:: AGENT_FIELDS
 *    	ApplicationEmail:: NOAGENT_FIELDS
 *     	ApplicationEmail:: STAFF_FIELDS
 *      ApplicationEmail:: TRELLO_FIELDS
 *  
 *  
 *  These Constant Arrays contains what to 'substitute' in email templates.
 *  	
 *   	ex.
 *    		// email_template.html
 *      	<html>
 *       		<head></head>
 *         		<body>
 *           		Hello, [!name!]<br>
 * 
 * 					Application # [!id!] has been submitted.<br>
 *           	</body>
 *       	</html>
 *        	
 *  Markups that need to be substituted are 'name' and 'id' 
 * 
 * 	Substitute Class takes 3 arguments : directory to an email template, an array of strings to be substituted for, and an array of strings to be substituted to.
 *  So having to get values of multiple keys in Category Class can be handy. 
 *   	
 * 	  	ex. 
 *     		new Substitute( __DIR__ . '/templates/email_template.html', array( 'name', 'id' ), array( 'John Cage', 'A012345' ) )
 * 
 *		----OUTPUT----
 * 
 * 			<html>
 *       		<head></head>
 *         		<body>
 *           		Hello, John Cage<br>
 * 
 * 					Application # A012345 has been submitted.<br>
 *           	</body>
 *       	</html>
 * 
 * 		---------------
 * 	
 * 
 **/ 

/* Includes */
require_once( __DIR__ . '/include/jsonRPCClient.php');
require_once( __DIR__ . '/include/substitute.php');
require_once( __DIR__ . '/include/security/security.php');

/* VEC Specifics */
require_once( __DIR__ . '/vec/application-staff.php');
require_once( __DIR__ . '/vec/application-form.php');
require_once( __DIR__ . '/vec/application-email.php');

define( 'ID', getUniqueKeyByDate() );

$secure = Security::getInstance();
$secure->startSession();
$secure->sanitize( $_POST ); 

get_template_part( 'page' ); 


/**
 *	Returns an unique key created by hashing date for primary key @ VEC server.
 **/ 
function getUniqueKeyByDate() {

	$key  = '';
	$date = getdate();

	$key .= chr( ( $date[ 'year' ] - 2016 ) + 65 );
	$key .= chr( ( $date[ 'mon' ] - 1 ) + 65 );

	if( $date[ 'mday' ] < 10 ) {

	    $key .= ( $date[ 'mday' ] - 1 ) . '.';

	} else {

	    $key .= chr( ( $date[ 'mday' ] - 10 ) + 65 ) . '.';

	}

	$ms   = ( $date[ 'hours' ] * 360000) + ( $date[ 'minutes' ] * 60000 ) + ( $date[ 'seconds' ] * 1000 ) + random_int( 0, 999 );
	$key .= strtoupper( substr_replace( str_pad( dechex( $ms ), 6, '0', STR_PAD_RIGHT ), '.', 3, 0 ) );

	return $key;

}


$applicationEmail = new ApplicationEmail();
$applicationEmail->send();


?>