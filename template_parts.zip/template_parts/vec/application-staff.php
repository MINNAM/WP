<?php

class ApplicationStaff { 

	private static $DEFAULT_RECIPIENTS;

	public function __construct( $role, $department = null, $language = null ) {	

		self::$DEFAULT_RECIPIENTS = array(

			"tech1@vec.ca",
			"tech2@vec.ca"

		);

		$query      = array( 'role' => $role );
		$meta_query = array();

		/* Need to refactor following code, but works */

		if( $department === null && $language === null ) {

			$this->getResult( new WP_User_Query( 

				array(

					'role'  => $role,
				)

			));

		} else if( $language === null ) {

			$this->getResult( new WP_User_Query( 

				array(

					'role'  => $role,

					'meta_query' => array( 

						array(

							'key' => 'department',
							'value' => $department
						),
				
					)

				)
			));

		} else if ( $department === null ) {

			$this->getResult( new WP_User_Query( 

				array(

					'role'  => $role,

					'meta_query' => array( 

						array(

							'key' => 'language',
							'value' => $language
						),
				
					)

				)
			));

		} else {

			$this->getResult( new WP_User_Query( 

				array(

					'role'  => $role,

					'meta_query' => array( 

						array(

							'key' => 'department',
							'value' => $department
						),

						array(

							'key' => 'language',
							'value' => $language
						),
				
					)

				)
			));

		}

	}

	private function getResult( $query ) {

		if ( ! empty( $query->results ) ) {
			
			foreach ( $query->results as $user ) {

				echo '<p>' . $user->display_name . '</p>';

			}

		} 
	}

}
?>