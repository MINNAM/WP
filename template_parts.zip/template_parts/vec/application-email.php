<?php 

class ApplicationEmail {

	const QUOTE   		  = '/../asset/email_templates/user_email-default.html';
	const AGENT   		  = '/../asset/email_templates/user_email-agent.html';
	const NOAGENT 		  = '/../asset/email_templates/user_email-noagent.html';
	const STAFF   		  = '/../asset/email_templates/staff_email.html';
	const TRELLO  		  = 'hello';

	const QUOTE_FIELDS    = array( "id",    "estimate", "link" );
	const AGENT_FIELDS    = array( "agent", "estimate", "id", "link" );
	const NOAGENT_FIELDS  = array( "name",  "id", "estimate", "link" );
	const STAFF_FIELDS    = array( "content" );
	const TRELLO_FIELDS   = array( "id", "estimate", "link" );

	const STUDENT_HEADERS = array( 'Content-Type: text/html; charset=UTF-8', 'From: VEC Admissions <apply@vec.ca>', 'Reply-To: apply@vec.ca' );
	const STAFF_HEADERS   = array( 'Content-Type: text/html; charset=UTF-8', 'From: VEC Admissions <apply@vec.ca>', 'Reply-To: apply@vec.ca' );
	const TRELLO_HEADERS  = array( 'Content-Type: text/html; charset=UTF-8', 'From: VEC Admissions <apply@vec.ca>', 'Reply-To: apply@vec.ca' );

	const THANKYOULINK    = 'http://vec.ca/quote-confirmation/';

	private $headers;
	private $subject;
	private $staff;
	private $applicationForm;
	private $isEffProgram;

	public function __construct() {

		$this->applicationForm = new ApplicationForm();
		$this->staff = new ApplicationStaff( 'Administrator', 'production', $this->applicationForm->student->get( 'language' ) );

		$this->isEffProgram = ( null !== $this->applicationForm->other->get( 'eff_program' ) );

	}

	private function writeForStudent() {

		$body;
		$templateDir;
		$templateType;
		
		$type    = $_POST[ 'next' ];
		$id      = constant( "ID" );
		$student = $this->applicationForm->student;
		$agent   = $this->applicationForm->agent;
		$link    = $this->link();

		switch( $type ) {

			case 1 : 	   // Default Template

				echo "<h1 style = 'color: blue;'>FOR STUDENT : DEFAULT</h1>";

				$body  = $this->isEffProgram ? array( $id, "", $link ) : array( $id, "$100,000", $link );
				$templateDir  = self::QUOTE;
				$templateType = self::QUOTE_FIELDS;

				break;

			case 0 : 	  // With Agent 

				if( $agent->exist() ) {

					echo "<h1 style = 'color: blue;'>FOR STUDENT : AGENT</h1>";
					$body  = $this->isEffProgram ? array( $agent->get( 'name' ), "" , $id, $link ) : array( $student->get( 'name' ), "$100,000" , $id, $link );
					$templateDir  = self::AGENT;
					$templateType = self::AGENT_FIELDS;

				} else {


					echo "<h1 style = 'color: blue;'>FOR STUDENT : NO AGENT</h1>";

					$body  = $this->isEffProgram ? array( $student->get( 'name' ), $id, "$100,000", $link ) : array( $student->get( 'name' ), $id, "$100,000", $link );
					$templateDir  = self::NOAGENT;
					$templateType = self::NOAGENT_FIELDS;

				}				

				break;

			default : // Without Agent

				

		}

		return new Substitute( __DIR__ . $templateDir, $templateType, $body ); // ->output();

	}

	public function writeForStaff() {

		$subject = 'Application #' . constant( "ID" );

		/* Prefix and Suffix for 'appendAll' function */
		$keyPrefix    = '<tr><td style = "width: 200px;"><b>';
		$keySuffix    = ':</b></td>';
		$valuePrefix  = '<td>';
		$valueSuffix  = '</td></tr>';


		echo "<br><h1 style = 'color: blue;'>FOR STAFF</h1>";

		$body = "<br><h3>Student Info:</h3><br>";
		$body .= "<table style = 'width: 500px;'>";

		$this->applicationForm->student->appendAll( $body, true, $keyPrefix, $keySuffix, $valuePrefix, $valueSuffix );

		$body .= "</table>";

		if( $this->applicationForm->agent->exist() ) {

			$body .= "<br><h3>Agent Info:</h3><br>";
			$body .= "<table style = 'width: 500px;'>";

			$this->applicationForm->agent->appendAll( $body, true, $keyPrefix, $keySuffix, $valuePrefix, $valueSuffix );

			$body .= "</table>";

		}
		
		$body .= "<br><h3>Program Info:</h3><br>";
		$body .= "<table style = 'width: 500px;'>";

		$this->applicationForm->program->appendAll( $body, true, $keyPrefix, $keySuffix, $valuePrefix, $valueSuffix );

		$body .= "</table>";
		
		return new Substitute( __DIR__ . self::STAFF, self::STAFF_FIELDS, array( $body ) ); // ->output();		

	}

	public function writeForTrello() {

		echo "<br><h1 style = 'color: blue;'>FOR TRELLO</h1>";

		$student = $this->applicationForm->student;
		$agent   = $this->applicationForm->agent;
		$program = $this->applicationForm->program;
		$other   = $this->applicationForm->other;

		$keyPrefix    = '**';
		$keySuffix    = ': **';
		$valuePrefix  = '';
		$valueSuffix  = '<br>';

		$body = '';

		$student->append( 'language',      $body, true, $keyPrefix, $keySuffix, $valuePrefix, $valueSuffix );
		$student->append( 'country',       $body, true, $keyPrefix, $keySuffix, $valuePrefix, $valueSuffix );
		$student->append( 'email',         $body, true, $keyPrefix, $keySuffix, $valuePrefix, $valueSuffix );
		$student->append( 'dob',           $body, true, $keyPrefix, $keySuffix, $valuePrefix, $valueSuffix );
		$student->append( 'accommodation', $body, true, $keyPrefix, $keySuffix, $valuePrefix, $valueSuffix );

		if( $agent->exist() ) {

			$agent->append( 'name', $body, true, $keyPrefix, $keySuffix, $valuePrefix, $valueSuffix );

		}
		
		$program->append( 'startdate', $body, true, $keyPrefix, $keySuffix, $valuePrefix, $valueSuffix );

		return $body;
	}
	
	public function link() { 

		$link  = '<a href="https://secure.vec.ca/apply/?"';
		$link .= http_build_query( $this->applicationForm->input ); /* $_POST Data */
		$link .= " target='_blank' style='font-size: 14px; font-family: \'Open Sans\', Open Sans, Arial, sans-serif; text-decoration: none; text-decoration: none; padding: 10px 14px; display: inline-block;'>Complete your application</a>";

		return $link;

	}

	public function mail( $param ) {

		$recipients = $param[ 'recipients' ];
		$subject    = $param[ 'subject' ];
		$body        = $param[ 'email' ];
		$headers    = $param[ 'headers' ];

		wp_mail( $recipients, $subject, $body, $headers );

	}

	public function send() {

		$this->mail( array( 

			'recipients' => 'design3@vec.ca',
			'subject' 	 => 'Process - For',
			'email' 	 => $this->writeForStudent()->output(),
			'headers' 	 => self::STAFF_HEADERS

		));

		$this->mail( array( 

			'recipients' => 'design3@vec.ca',
			'subject' 	 => 'Process - For Trello',
			'email' 	 => $this->writeForTrello(),
			'headers' 	 => self::STAFF_HEADERS

		));

		if( /** $this->applicationForm->input[ 'next' ] == 1 **/ true ) {

			$this->mail( array( 

				'recipients' => 'design3@vec.ca',
				'subject' 	 => 'Process - For Staff',
				'email' 	 => $this->writeForStaff()->output(),
				'headers' 	 => self::STAFF_HEADERS

			));

		}

	}

}

?>