<?php 

class ApplicationForm {

	const PROGRAM = 'program_';
	const STUDENT = 'student_';
	const AGENT   = 'agent_';
	const OTHER   = 'other_';
	
	public $input;
	public $program;
	public $student;
	public $agent;
	public $other;

	public function __construct() {

		$this->input   = $_POST;
		$this->program = new Category();
		$this->student = new Student(); // Child Class of Category Class
		$this->agent   = new Category();
		$this->other   = new Category();

		foreach ( $this->input as $key => $value ) {

            if( strpos( $key, self::PROGRAM ) !== FALSE  ) {

            	if( isset( $value ) ) {

            		$this->program->add( str_replace( self::PROGRAM, '', $key ) , $value );

            	}

            } else if( strpos( $key, self::STUDENT ) !== FALSE  ) { 

            	if( isset( $value ) ) {

            		$this->student->add( str_replace( self::STUDENT, '', $key ), $value );

            	}

            } else if( strpos( $key, self::AGENT ) !== FALSE  ) { 

            	if( isset( $value ) ) {

            		$this->agent->add( str_replace( self::AGENT, '', $key ), $value );

            	}

            } else {

            	if( isset( $value ) ) {

            		$this->other->add( str_replace( self::OTHER, '', $key ), $value );

            	}

            }
            
        }

        $this->student->reorder( 'name', 'language' );

	}

}

class Category {

	protected $values = array();

	public function exist() {

		return count( $this->values ) != 0; 

	}

	public function add( $key, $value ) {

		$this->values[ $key ] = $value; 

	}

	public function reorder( $key1 , $key2 ) {

		$a = array_search( $key1, array_keys( $this->values ) );
		$b = array_search( $key2, array_keys( $this->values ) );

		$temp1 = array_splice( $this->values, $a, 1 );
		$temp2 = array_splice( $this->values, 0, $b );

		$this->values = array_merge( $temp2, $temp1, $this->values );

	}

	/**
	 * 	'get' function loops through $values array, compares with key of $keys array,
	 *   and returns values with the identical keys. 
	 *   
	 *  ex. $value = [ 'name' => 'John', 'age' => 33, 'gender' => 'male' ]
	 *      parameter ) $keys = [ 'name', 'age' ]
	 *      
	 *      because key of $keys array is numberic, it needs to be reversed 
	 * 
	 * 		$keys = [ 'name' => 0, 'age => 1' ]
	 * 
	 * 		with php function, array_intersect_key 
	 *   	array of values that two arrays ( $values & $keys ) intersect in key will be returned. 
	 * 
	 * 		$result  = [ 'John', 33 ]
	 * 
	 **/ 
	public function get( $keys = null ) {

		if( is_string( $keys ) ) {

			return $this->values[ $keys ]; 

		}else if( is_array( $keys ) ) {

			$result = array_intersect_key( $this->values, array_flip( $keys ) );

			if( count( $result ) < 1 ) {

				return null;

			}

 			return $result;

		}

		return $this->values;

	}


	public function append( $key, &$str, $ucfirst = true, $keyPrefix  = '', $keySuffix  = '', $valuePrefix = '', $valueSuffix = ''  ) {

		if( isset( $this->values[ $key ] )  ) {

			$value = $this->values[ $key ];

			if( $ucfirst ) {

				$key = str_replace( '_', ' ', ucfirst( $key ) );

			}
			

			$str .= "$keyPrefix $key $keySuffix $valuePrefix $value $valueSuffix";

		}


	}

	public function appendAll( &$str, $ucfirst = true, $keyPrefix  = '', $keySuffix  = '', $valuePrefix = '', $valueSuffix = ''  ) {

		foreach( $this->values as $key => $value ) {

			if( $ucfirst ) {

				$key = str_replace( '_', ' ', ucfirst( $key ) );

			}
			

			$str .= "$keyPrefix $key $keySuffix $valuePrefix $value $valueSuffix";

		}

	}


}

class Student extends Category {

	/**
	 *	Overriden 'add' function simply looks for firstname and lastname then 
	 * 	adds another key/value 'name', a combined of the two. 
	 **/ 
	public function add( $key, $value ) {

		if( $key === "firstname" ) {

			$this->values[ $key ] = $value; 
			$this->values[ 'name' ] = $value; 

		} else if ( $key === "lastname" ) {

			$this->values[ $key ] = $value; 
			$this->values[ 'name' ] .= " $value"; 

		} else {

			$this->values[ $key ] = $value; 
		}

	}

	/**
	 * 
	 * Excluding firstname and lastname
	 * 
	 **/ 
	public function appendAll( &$str, $ucfirst = true, $keyPrefix  = '', $keySuffix  = '', $valuePrefix = '', $valueSuffix = ''  ) {

		foreach( $this->values as $key => $value ) {

			if( $key !== 'firstname' && $key !== 'lastname' ) {

				if( $ucfirst ) {

					$key = str_replace( '_', ' ', ucfirst( $key ) );

				}
			

				$str .= "$keyPrefix $key $keySuffix $valuePrefix $value $valueSuffix";

			}

		}

	}

}

?>