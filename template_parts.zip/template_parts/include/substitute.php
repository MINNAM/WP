<?php 

class Substitute {

	const START = '[!';
	const END   = '!]';

	private $source;
	private $search;
	private $replace;
	private $output;

	public function __construct( $dir, $search, $replace ) {

		$this->source   = file_get_contents( $dir );
		$this->search   = $search;
		$this->replace  = $replace;

		array_walk( $this->search, array( $this, 'parseSearch' ) );

		$this->substitute();

	}

	public function parseSearch( &$item, &$key ) {

		$item = self::START . $item . self::END;

	}

	public function getSource() {

		return $this->source;

	}

	public function getSearch() {

		return $this->search;

	}

	public function getReplace() {

		return $this->replace;
	}

	public function output() {

		return $this->output;

	}

	public function substitute() {
		
		$this->output = str_replace( $this->search, $this->replace, $this->source );

	}

}
?>